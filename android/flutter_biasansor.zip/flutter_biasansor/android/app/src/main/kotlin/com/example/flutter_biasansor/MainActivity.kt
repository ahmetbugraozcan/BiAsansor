package com.example.flutter_biasansor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
