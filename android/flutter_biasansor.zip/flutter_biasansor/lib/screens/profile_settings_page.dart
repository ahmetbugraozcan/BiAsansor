import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_biasansor/core/extensions/context_extension.dart';
import 'package:flutter_biasansor/errors.dart';
import 'package:flutter_biasansor/viewmodel/viewmodel.dart';
import 'package:flutter_biasansor/widgets/platform_duyarli_alert_dialog.dart';
import 'package:provider/provider.dart';

class ProfileSettingsPage extends StatefulWidget {
  @override
  _ProfileSettingsPageState createState() => _ProfileSettingsPageState();
}

class _ProfileSettingsPageState extends State<ProfileSettingsPage> {
  @override
  Widget build(BuildContext context) {
    var _viewModel = Provider.of<ViewModel>(context);
    var _user = _viewModel.user;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text('Ayarlar'),
      ),
      body: ListView(
        children: [
          Container(
            color: Colors.grey.withOpacity(0.3),
            child: ListTile(
              title: Text(
                'Hesap Bilgilerim',
                style: context.theme.textTheme.subtitle2.copyWith(fontSize: 16),
              ),
              trailing: TextButton(
                onPressed: () {},
                child: Text(
                  'Kaydet',
                  style: context.theme.textTheme.button
                      .copyWith(color: Colors.blue[800]),
                ),
              ),
            ),
          ),
          Padding(
            padding: context.paddingAllMedium,
            child: CircleAvatar(
              backgroundColor: Colors.white,
              radius: 64,
              child: Image.network(_user.profileUrl),
            ),
          ),
          Align(
              alignment: Alignment.center,
              child: Text(
                'Profil Fotoğrafını Değiştir',
                style: context.theme.textTheme.subtitle1.copyWith(
                    color: Colors.blue[900], fontWeight: FontWeight.w500),
              )),
          ListTile(
            title: Padding(
                padding: context.paddingAllLow,
                child: Text('Kullanıcı Adı',
                    style: context.theme.textTheme.subtitle1.copyWith(
                        color: Colors.black54, fontWeight: FontWeight.w500))),
            subtitle: AspectRatio(
              aspectRatio: 8,
              child: TextFormField(
                initialValue: _user.userName,
                decoration: InputDecoration(
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 14.0, horizontal: 10.0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12))),
                ),
              ),
            ),
          ),
          ListTile(
            title: Padding(
                padding: context.paddingAllLow,
                child: Text(
                  'E-Posta',
                  style: context.theme.textTheme.subtitle1.copyWith(
                      color: Colors.black54, fontWeight: FontWeight.w500),
                )),
            subtitle: AspectRatio(
              aspectRatio: 8,
              child: TextFormField(
                initialValue: _user.email,
                decoration: InputDecoration(
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 14.0, horizontal: 10.0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12))),
                ),
              ),
            ),
          ),
          ListTile(
            title: Padding(
                padding: context.paddingAllLow,
                child: Text('Konum',
                    style: context.theme.textTheme.subtitle1.copyWith(
                        color: Colors.black54, fontWeight: FontWeight.w500))),
            subtitle: AspectRatio(
              aspectRatio: 8,
              child: TextFormField(
                initialValue: '-',
                decoration: InputDecoration(
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 14.0, horizontal: 10.0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12))),
                ),
              ),
            ),
          ),
          ListTile(
            title: Padding(
                padding: context.paddingAllLow,
                child: Text('Adres',
                    style: context.theme.textTheme.subtitle1.copyWith(
                        color: Colors.black54, fontWeight: FontWeight.w500))),
            subtitle: AspectRatio(
              aspectRatio: 8,
              child: TextFormField(
                initialValue: 'Eğriköprü mahallesi',
                decoration: InputDecoration(
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 14.0, horizontal: 10.0),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12))),
                ),
              ),
            ),
          ),
          Divider(),
          Padding(
            padding:
                EdgeInsets.symmetric(horizontal: context.dynamicWidth(0.01)),
            child: ListTile(
              title: Text('Genel',
                  style:
                      context.theme.textTheme.subtitle2.copyWith(fontSize: 15)),
              trailing: Text(
                'Oturumu Kapat',
                style: context.theme.textTheme.subtitle1
                    .copyWith(color: Colors.red, fontSize: 15),
              ),
            ),
          )
          // Padding(
          //   padding: EdgeInsets.symmetric(
          //       vertical: context.dynamicHeight(0.005),
          //       horizontal: context.dynamicWidth(0.044)),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //     children: [
          //       Text('Genel',
          //           style: context.theme.textTheme.subtitle2
          //               .copyWith(fontSize: 16)),
          //       TextButton(
          //         onPressed: () async {
          //           try {
          //             Navigator.pop(context);
          //             //başka bi çözüm bulsak daha iyi olabilir
          //             await Future.delayed(Duration(seconds: 1));
          //             await _viewModel.signOut();
          //           } on PlatformException catch (ex) {
          //             return PlatformDuyarliAlertDialog(
          //               title: 'Çıkış Yapılırken Hata',
          //               body: Errors.showError(ex.toString()),
          //               mainButtonText: 'Tamam',
          //             ).show(context);
          //           }
          //         },
          //         child: Text(
          //           'Oturumu Kapat',
          //           style: context.theme.textTheme.subtitle1
          //               .copyWith(color: Colors.red),
          //         ),
          //       )
          //     ],
          //     // children: [
          //     //   ListTile(
          //     //     title: Text('Genel',
          //     //         style: context.theme.textTheme.subtitle2
          //     //             .copyWith(fontSize: 16)),
          //     //   ),
          //     //   ListTile(
          //     //     onTap: () async {
          //     //       try {
          //     //         Navigator.pop(context);
          //     //         //başka bi çözüm bulsak daha iyi olabilir
          //     //         await Future.delayed(Duration(seconds: 1));
          //     //         await _viewModel.signOut();
          //     //       } on PlatformException catch (ex) {
          //     //         return PlatformDuyarliAlertDialog(
          //     //           title: 'Çıkış Yapılırken Hata',
          //     //           body: Errors.showError(ex.toString()),
          //     //           mainButtonText: 'Tamam',
          //     //         ).show(context);
          //     //       }
          //     //     },
          //     //     title: Text(
          //     //       'Oturumu Kapat',
          //     //       style: context.theme.textTheme.subtitle1
          //     //           .copyWith(color: Colors.red),
          //     //     ),
          //     //   ),
          //     // ],
          //   ),
          // )
        ],
      ),
    );
  }
}
