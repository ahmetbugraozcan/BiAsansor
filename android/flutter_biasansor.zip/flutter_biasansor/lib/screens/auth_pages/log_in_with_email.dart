import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_biasansor/core/extensions/context_extension.dart';
import 'package:flutter_biasansor/errors.dart';
import 'file:///C:/ornekler/flutter_biasansor/lib/screens/loading_page.dart';

import 'package:flutter_biasansor/viewmodel/viewmodel.dart';
import 'package:flutter_biasansor/widgets/platform_duyarli_alert_dialog.dart';
import 'package:flutter_biasansor/widgets/social_log_in_button.dart';
import 'package:provider/provider.dart';

class LoginWithEmailPage extends StatefulWidget {
  @override
  _LoginWithEmailPageState createState() => _LoginWithEmailPageState();
}

class _LoginWithEmailPageState extends State<LoginWithEmailPage> {
  String email;
  String sifre;
  final GlobalKey<FormState> _emailKey = GlobalKey<FormState>();
  final GlobalKey<FormState> _passwordKey = GlobalKey<FormState>();
  bool _hidePassword;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _hidePassword = true;
  }

  @override
  Widget build(BuildContext context) {
    final _viewModel = Provider.of<ViewModel>(context);
    return _viewModel.state == ViewState.Busy
        ? IgnorePointer(child: buildLoginPageBody(context, _viewModel))
        : buildLoginPageBody(context, _viewModel);
  }

  SafeArea buildLoginPageBody(BuildContext context, ViewModel _viewModel) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          leading: buildAppbarCloseButton(context),
          elevation: 0,
          backgroundColor: Colors.transparent,
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(
              horizontal: context.dynamicWidth(0.05),
              vertical: context.dynamicHeight(0.02)),
          child: Stack(
            children: [
              _viewModel.state == ViewState.Busy
                  ? Center(child: CircularProgressIndicator())
                  : SizedBox(),
              Column(
                children: [
                  Spacer(flex: 1),
                  buildGirisYapText(context),
                  Spacer(flex: 2),
                  Form(
                      key: _emailKey,
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      child: TextFormField(
                        validator: (value) {
                          var emailRegExp = RegExp(
                              r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
                          if (!emailRegExp.hasMatch(value)) {
                            return 'Lütfen geçerli bir email giriniz';
                          } else {
                            email = value;
                            return null;
                          }
                        },
                        decoration: InputDecoration(
                          hintText: 'Email',
                          // border: OutlineInputBorder(
                          //     borderRadius: BorderRadius.all(Radius.circular(8)))
                        ),
                      )),
                  Spacer(flex: 1),
                  Form(
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      key: _passwordKey,
                      child: TextFormField(
                        obscureText: _hidePassword,
                        validator: (value) {
                          if (value.length < 1) {
                            return 'Şifrenizi giriniz';
                          } else {
                            sifre = value;
                            return null;
                          }
                        },
                        decoration: InputDecoration(
                            hintText: 'Şifre',
                            suffixIcon: IconButton(
                                icon: Icon(
                                  _hidePassword
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: Colors.black38,
                                ),
                                onPressed: () {
                                  setState(() {
                                    _hidePassword = !_hidePassword;
                                  });
                                })
                            // border: OutlineInputBorder(
                            //     borderRadius: BorderRadius.all(Radius.circular(8)))
                            ),
                      )),
                  Spacer(flex: 2),
                  SocialLoginButton(
                    elevation: 2,
                    borderRadius: 22,
                    height: context.dynamicHeight(0.06),
                    width: context.dynamicWidth(1),
                    buttonText: Text(
                      'Giriş Yap',
                      style: context.theme.textTheme.button
                          .copyWith(color: Colors.white),
                    ),
                    onPressed: () async {
                      bool isCompleted = true;
                      _emailKey.currentState.validate();
                      _passwordKey.currentState.validate();
                      if (_emailKey.currentState.validate() &&
                          _passwordKey.currentState.validate()) {
                        try {
                          await _viewModel.signInWithEmailAndPassword(
                              email, sifre);
                        } catch (ex) {
                          isCompleted = false;
                          await PlatformDuyarliAlertDialog(
                                  title: "Kullanıcı Oluşturulamadı",
                                  body: Errors.showError(ex.code),
                                  mainButtonText: 'Tamam')
                              .show(context);
                        } finally {
                          if (isCompleted) {
                            Navigator.pop(context);
                          }
                        }
                      }
                    },
                    buttonColor: context.theme.buttonColor,
                  ),
                  Spacer(
                    flex: 2,
                  ),
                  Text("Ya da"),
                  Spacer(
                    flex: 2,
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SocialLoginButton(
                        width: context.dynamicWidth(0.2),
                        height: context.dynamicWidth(0.13),
                        shape: CircleBorder(),
                        buttonColor: context.facebookColor,
                        buttonImage: Image.asset(
                          "assets/facebook_logo.png",
                          scale: 25,
                        ),
                        onPressed: () async {
                          try {
                            await _viewModel.signInWithFacebook();
                          } on PlatformException catch (ex) {
                            debugPrint("Oturum açma hata login page : " +
                                ex.toString());
                          }
                          if (_viewModel.user != null) {
                            Navigator.pop(context);
                            print('Email : ' + _viewModel.user.email);
                          }
                        },
                      ),
                      SocialLoginButton(
                        width: context.dynamicWidth(0.2),
                        height: context.dynamicWidth(0.13),
                        shape: CircleBorder(),
                        buttonColor: context.googleRedColor,
                        buttonImage: Image.asset(
                          "assets/google_white.png",
                          scale: 25,
                        ),
                        onPressed: () async {
                          try {
                            await _viewModel.signInWithGoogle();
                          } on PlatformException catch (ex) {
                            debugPrint('Oturum açma hata login page : ' +
                                Errors.showError(ex.code));
                          }
                          if (_viewModel.user != null) {
                            Navigator.pop(context);
                            print('Email : ' + _viewModel.user.email);
                          }
                        },
                      ),
                    ],
                  ),
                  Spacer(flex: 13),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Align buildGirisYapText(BuildContext context) {
    return Align(
        alignment: Alignment.centerLeft,
        child: Text(
          'Giriş Yap',
          style: context.theme.textTheme.headline5,
        ));
  }

  InkWell buildAppbarCloseButton(BuildContext context) {
    return InkWell(
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
        //Klavye açıkken pop yapıldığında taşma hatası verdiğinden bunu yaptım
        Future.delayed(Duration(milliseconds: 100))
            .then((value) => Navigator.pop(context));
      },
      child: Icon(Icons.close),
    );
  }
}
