import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_biasansor/core/extensions/context_extension.dart';
import 'package:flutter_biasansor/locator.dart';
import 'package:flutter_biasansor/model/useracc.dart';
import 'package:flutter_biasansor/screens/profile_settings_page.dart';

import 'package:flutter_biasansor/services/firestore_database_service.dart';
import 'package:flutter_biasansor/viewmodel/viewmodel.dart';
import 'package:provider/provider.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  var firestoreDBService = locator<FirestoreDatabaseService>();
  bool isReadyToNavigateSettings = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var _viewModel = Provider.of<ViewModel>(context);
    var _user = _viewModel.user;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        actions: [buildSettingsButton()],
        title: Text(
          'Profilim',
          style: context.theme.textTheme.headline5,
        ),
      ),
      body: FutureBuilder(
        future: firestoreDBService.readUser(_user.userID),
        builder: (BuildContext context, AsyncSnapshot<UserAcc> snapshot) {
          // var width = context.size.width;
          // var height = context.size.height;
          if (snapshot.data != null) {
            _user = snapshot.data;
            //bu mantıksız oldu bunu değiştirelim
            _viewModel.user.profileUrl = _user.profileUrl;
            isReadyToNavigateSettings = true;
          }
          return snapshot.data == null
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : Center(
                  child: Column(
                    children: [
                      Expanded(flex: 4, child: buildUserAvatar(context, _user)),
                      Expanded(child: buildUserNameText(_user, context)),
                      Expanded(
                        flex: 10,
                        child: Card(
                          elevation: 20,
                          child: Column(
                            children: [
                              Expanded(child: buildKullaniciAdiListTile(_user)),
                              Expanded(child: buildEmailListTile(_user)),
                              Expanded(child: buildKonumListTile()),
                              Expanded(child: buildAdresListTile()),
                              buildEmailVerifiedCard(context)
                            ],
                          ),
                        ),
                      ),
                      Spacer(flex: 1),
                    ],
                  ),
                );
        },
      ),
    );
  }

  IconButton buildSettingsButton() {
    return IconButton(
        icon: Icon(Icons.settings),
        onPressed: () {
          if (isReadyToNavigateSettings) {
            Navigator.push(
                context,
                CupertinoPageRoute(
                  builder: (context) => ProfileSettingsPage(),
                ));
          }
        });
  }

  ListTile buildKullaniciAdiListTile(UserAcc _user) {
    return ListTile(
      leading: Icon(Icons.person),
      title: Text('Kullanıcı Adı'),
      subtitle: Text(_user.userName),
    );
  }

  ListTile buildEmailListTile(UserAcc _user) {
    return ListTile(
      title: Text("E-posta"),
      leading: Icon(Icons.mail),
      subtitle: Text(_user.email),
    );
  }

  ListTile buildKonumListTile() {
    return ListTile(
      leading: Icon(Icons.location_on),
      title: Text('Konum'),
      subtitle: Text('-'),
    );
  }

  ListTile buildAdresListTile() {
    return ListTile(
      leading: Icon(Icons.map),
      title: Text('Adres'),
      subtitle: Text(' '),
    );
  }

  MaterialButton buildLogOutButton(BuildContext context) {
    return MaterialButton(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(24))),
      color: context.theme.buttonColor,
      onPressed: () {},
      child: Text(
        'Çıkış Yap',
        style: context.theme.textTheme.headline6.copyWith(
          fontWeight: FontWeight.w400,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget buildUserAvatar(BuildContext context, UserAcc _user) {
    return AspectRatio(
      aspectRatio: 0.7,
      child: CircleAvatar(
        backgroundColor: Colors.white,
        child: Image.network(_user.profileUrl),
      ),
    );
  }

  Widget buildUserNameText(UserAcc _user, BuildContext context) {
    return Text('Hoşgeldiniz, ' + _user.userName,
        style: context.theme.textTheme.headline6
            .copyWith(fontWeight: FontWeight.w300));
  }

  Widget buildEmailVerifiedCard(BuildContext context) {
    return Card(
      color: Colors.green,
      child: ListTile(
        leading: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.verified_user,
            size: 33,
            color: Colors.white,
          ),
        ),
        title: Text(
          'Emailiniz doğrulanmıştır.',
          style:
              context.theme.textTheme.bodyText2.copyWith(color: Colors.white),
        ),
      ),
    );
  }

  Card buildEmailNotVerifiedCard(BuildContext context) {
    return Card(
      color: Colors.red,
      child: ListTile(
        leading: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.error,
            size: 33,
            color: Colors.white,
          ),
        ),
        title: Text(
          'Email henüz doğrulanmamış.',
          style:
              context.theme.textTheme.bodyText2.copyWith(color: Colors.white),
        ),
      ),
    );
  }
}
