import 'package:flutter/material.dart';
import 'package:flutter_biasansor/viewmodel/viewmodel.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    var _viewModel = Provider.of<ViewModel>(context);
    var _user = _viewModel.user;
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(
          children: [
            Text("Home Page"),
            TextButton(
              onPressed: () async {
                await _viewModel.signOut();
              },
              child: Text("Çıkış Yap"),
            ),
          ],
        ),
      ),
    );
  }
}
