import 'package:flutter/material.dart';

enum TabItem {
  Home,
  Search,
  Profile,
}

class TabItemData {
  final IconData icon;
  final String title;

  TabItemData(this.icon, this.title);

  static Map<TabItem, TabItemData> allTabs = {
    TabItem.Home: TabItemData(Icons.home, 'Menü'),
    TabItem.Profile: TabItemData(Icons.supervised_user_circle, 'Profil'),
    TabItem.Search: TabItemData(Icons.search, 'Ara')
  };
}
