import 'package:flutter/cupertino.dart';
import 'package:flutter_biasansor/locator.dart';
import 'package:flutter_biasansor/model/useracc.dart';
import 'package:flutter_biasansor/repository/user_repository.dart';
import 'package:flutter_biasansor/services/auth_base.dart';

enum ViewState { Idle, Busy }

class ViewModel with ChangeNotifier implements AuthBase {
  final UserRepository _userRepository = locator<UserRepository>();
  UserAcc _user;

  ViewState _state = ViewState.Idle;
  ViewState get state => _state;

  UserAcc get user => _user;

  set state(ViewState value) {
    _state = value;
    notifyListeners();
  }

  ViewModel() {
    currentUser();
  }
  @override
  Future<UserAcc> createUserWithEmailAndPassword(
      String email, String sifre) async {
    try {
      state = ViewState.Busy;
      _user =
          await _userRepository.createUserWithEmailAndPassword(email, sifre);
      if (_user != null) {
        return _user;
      } else {
        print('Viewmodel createuserwithemail boş döndü');
        return null;
      }
    } finally {
      state = ViewState.Idle;
    }
  }

  @override
  Future<UserAcc> currentUser() async {
    try {
      state = ViewState.Busy;
      _user = await _userRepository.currentUser();
      if (_user != null) {
        return _user;
      } else {
        print('usermodel currentuser user boş döndü');
        return null;
      }
    } catch (ex) {
      print('Usermodel currentuser hata : ' + ex.toString());
      return null;
    } finally {
      state = ViewState.Idle;
    }
  }

  @override
  Future<UserAcc> signInWithEmailAndPassword(String email, String sifre) async {
    try {
      state = ViewState.Busy;
      _user = await _userRepository.signInWithEmailAndPassword(email, sifre);
      if (_user != null) {
        return _user;
      } else {
        print('Usermodel signinemail null döndü');
        return null;
      }
    } finally {
      state = ViewState.Idle;
    }
  }

  @override
  Future<UserAcc> signInWithFacebook() async {
    try {
      state = ViewState.Busy;
      _user = await _userRepository.signInWithFacebook();
      if (_user != null) {
        return _user;
      } else {
        print("UserModel facebooksignin boş döndü");
        return null;
      }
    } finally {
      state = ViewState.Idle;
    }
  }

  @override
  Future<UserAcc> signInWithGoogle() async {
    try {
      state = ViewState.Busy;
      _user = await _userRepository.signInWithGoogle();
      if (_user != null) {
        return _user;
      } else {
        print("usermodel googlesignin user boş döndü");
        return null;
      }
    } finally {
      state = ViewState.Idle;
    }
  }

  @override
  Future<bool> signOut() async {
    try {
      state = ViewState.Busy;
      var result = await _userRepository.signOut();
      if (result) {
        _user = null;
        return result;
      }
    } finally {
      state = ViewState.Idle;
    }
  }
}
