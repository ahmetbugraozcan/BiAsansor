import 'package:flutter_biasansor/locator.dart';
import 'package:flutter_biasansor/model/useracc.dart';
import 'package:flutter_biasansor/services/auth_base.dart';
import 'package:flutter_biasansor/services/fake_auth_service.dart';
import 'package:flutter_biasansor/services/firebase_auth_service.dart';
import 'package:flutter_biasansor/services/firestore_database_service.dart';

enum AppMode { DEBUG, RELEASE }

class UserRepository implements AuthBase {
  AppMode appMode = AppMode.RELEASE;
  final FirebaseAuthService _firebaseAuthService =
      locator<FirebaseAuthService>();
  final FakeAuthenticationService _fakeAuthenticationService =
      locator<FakeAuthenticationService>();
  final FirestoreDatabaseService _firestoreDatabaseService =
      locator<FirestoreDatabaseService>();
  @override
  Future<UserAcc> createUserWithEmailAndPassword(
      String email, String sifre) async {
    if (appMode == AppMode.RELEASE) {
      var _userAcc = await _firebaseAuthService.createUserWithEmailAndPassword(
          email, sifre);
      var sonuc = await _firestoreDatabaseService.saveUser(_userAcc);
      if (sonuc) {
        return _userAcc;
      } else {
        print("repo firestoresaveuser hata");
        return null;
      }
    } else {
      return await _fakeAuthenticationService.createUserWithEmailAndPassword(
          email, sifre);
    }
  }

  @override
  Future<UserAcc> currentUser() async {
    if (appMode == AppMode.RELEASE) {
      var _userAcc = await _firebaseAuthService.currentUser();
      if (_userAcc != null) {
        return await _firestoreDatabaseService.readUser(_userAcc.userID);
      } else {
        return null;
      }
    } else {
      return await _fakeAuthenticationService.currentUser();
    }
  }

  @override
  Future<UserAcc> signInWithEmailAndPassword(String email, String sifre) async {
    if (appMode == AppMode.RELEASE) {
      var _userAcc =
          await _firebaseAuthService.signInWithEmailAndPassword(email, sifre);
      return await _firestoreDatabaseService.readUser(_userAcc.userID);
    } else {
      return await _fakeAuthenticationService.signInWithEmailAndPassword(
          email, sifre);
    }
  }

  @override
  Future<UserAcc> signInWithFacebook() async {
    if (appMode == AppMode.RELEASE) {
      var _userAcc = await _firebaseAuthService.signInWithFacebook();
      var _sonuc = await _firestoreDatabaseService.saveUser(_userAcc);
      if (_sonuc) {
        return await _firestoreDatabaseService.readUser(_userAcc.userID);
      } else {
        await _firebaseAuthService.signOut();
        return null;
      }
    } else {
      var _userAcc = await _fakeAuthenticationService.signInWithFacebook();
      return _userAcc;
    }
  }

  @override
  Future<UserAcc> signInWithGoogle() async {
    if (appMode == AppMode.RELEASE) {
      var _userAcc = await _firebaseAuthService.signInWithGoogle();
      bool _sonuc = await _firestoreDatabaseService.saveUser(_userAcc);
      if (_sonuc) {
        return await _firestoreDatabaseService.readUser(_userAcc.userID);
      } else {
        await _firebaseAuthService.signOut();
        return null;
      }
    } else {
      var _userAcc = await _fakeAuthenticationService.signInWithGoogle();
      return _userAcc;
    }
  }

  @override
  Future<bool> signOut() async {
    if (appMode == AppMode.RELEASE) {
      var result = await _firebaseAuthService.signOut();
      return result;
    } else {
      var result = await _fakeAuthenticationService.signOut();
      return result;
    }
  }
}
