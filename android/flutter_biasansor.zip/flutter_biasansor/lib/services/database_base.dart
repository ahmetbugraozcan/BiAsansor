import 'package:flutter_biasansor/model/useracc.dart';

abstract class DBBase {
  Future<bool> saveUser(UserAcc user);
  Future<UserAcc> readUser(String id);
}
