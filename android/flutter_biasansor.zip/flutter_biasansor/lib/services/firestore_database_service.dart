import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_biasansor/model/useracc.dart';
import 'package:flutter_biasansor/services/database_base.dart';

class FirestoreDatabaseService implements DBBase {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Future<UserAcc> readUser(String id) async {
    var _readedUser = await _firestore.collection('users').doc(id).get();
    // print("user id : " + id);
    // print(_readedUser.data());
    var user = UserAcc.fromMap(_readedUser.data());
    return user;
  }

  @override
  Future<bool> saveUser(UserAcc userAcc) async {
    await _firestore
        .collection('users')
        .doc(userAcc.userID)
        .set(userAcc.toMap());
    return true;
  }
}
