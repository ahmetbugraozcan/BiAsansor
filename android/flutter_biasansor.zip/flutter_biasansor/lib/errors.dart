class Errors {
  static String showError(String errorCode) {
    switch (errorCode) {
      case 'user-not-found':
        return 'Böyle bir kullanıcı bulunamadı';
      case 'account-exists-with-different-credential':
        return 'Bu email zaten mevcut.';
      default:
        return 'Bir hata oluştu...';
    }
  }
}
