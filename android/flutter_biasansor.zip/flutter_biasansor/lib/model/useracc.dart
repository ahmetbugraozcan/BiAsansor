import 'package:flutter/cupertino.dart';

class UserAcc {
  String userID;
  String email;
  String userName;
  String profileUrl;

  UserAcc({@required this.email, @required this.userID});

  Map<String, dynamic> toMap() {
    return {
      'userID': userID,
      'email': email,
      'userName': userName ?? email.split('@')[0],
      'profileUrl':
          profileUrl ?? 'https://cdn.onlinewebfonts.com/svg/img_264570.png',
    };
  }

  UserAcc.fromMap(Map<String, dynamic> map)
      : userID = map['userID'],
        email = map['email'],
        userName = map['userName'],
        profileUrl = map['profileUrl'];
}
